-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-07-2018 a las 10:48:15
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_easycredit`
--

DELIMITER $$
--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `maxDetalle` () RETURNS INT(11) NO SQL
RETURN (SELECT max(id_detalle) from detalle)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

CREATE TABLE `detalle` (
  `id_detalle` int(11) NOT NULL,
  `Monto` double NOT NULL,
  `edad` int(11) NOT NULL,
  `forma_de_pago` varchar(30) NOT NULL,
  `plazo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`id_detalle`, `Monto`, `edad`, `forma_de_pago`, `plazo`) VALUES
(1, 5000, 25, 'Visa', 6),
(2, 2000, 25, 'Visa', 9),
(3, 10000, 25, 'Visa', 3),
(4, 12000, 25, 'MaserCard', 9),
(5, 1000, 25, 'MaserCard', 3),
(6, 30000, 25, 'MaserCard', 9),
(7, 5000, 31, 'Pago en efectivo', 3),
(8, 5000, 31, 'Pago en efectivo', 3),
(9, 5000, 31, 'Pago en efectivo', 3),
(10, 4500, 32, 'Pago en efectivo', 6),
(11, 9000, 32, 'Pago en efectivo', 6),
(12, 900, 32, 'Visa', 3),
(13, 5000, 50, 'Pago en efectivo', 9),
(14, 6000, 50, 'Pago en efectivo', 3),
(15, 6500, 50, 'Pago en efectivo', 3),
(16, 6500, 53, 'Santander', 9),
(17, 2000, 18, 'MasterCard', 6),
(18, 3000, 26, 'PayPal', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `ID_Solicitud` int(11) NOT NULL,
  `Detalle` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  `Autorizacion` tinyint(1) NOT NULL,
  `usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`ID_Solicitud`, `Detalle`, `Estado`, `Autorizacion`, `usuario`) VALUES
(1, 1, 1, 1, 8),
(2, 2, 0, 1, 8),
(3, 3, 0, 1, 8),
(4, 4, 1, 1, 8),
(5, 5, 0, 1, 8),
(6, 6, 0, 3, 8),
(7, 7, 0, 1, 19),
(8, 8, 1, 1, 19),
(9, 9, 0, 0, 19),
(12, 10, 0, 1, 19),
(13, 11, 0, 0, 19),
(14, 12, 0, 0, 19),
(15, 13, 0, 0, 21),
(16, 14, 0, 0, 21),
(17, 15, 0, 0, 21),
(18, 16, 0, 1, 21),
(19, 17, 0, 0, 20),
(20, 18, 0, 0, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `userID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`userID`, `username`) VALUES
(8, 'victor'),
(19, 'iris'),
(20, 'ana'),
(21, 'pablo'),
(22, '');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_historial`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_historial` (
`username` varchar(50)
,`ID_Solicitud` int(11)
,`Detalle` int(11)
,`Estado` tinyint(1)
,`Autorizacion` tinyint(1)
,`usuario` int(11)
,`id_detalle` int(11)
,`Monto` double
,`edad` int(11)
,`forma_de_pago` varchar(30)
,`plazo` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_solicitudespendientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_solicitudespendientes` (
`username` varchar(50)
,`ID_Solicitud` int(11)
,`Detalle` int(11)
,`Estado` tinyint(1)
,`Autorizacion` tinyint(1)
,`usuario` int(11)
,`id_detalle` int(11)
,`Monto` double
,`edad` int(11)
,`forma_de_pago` varchar(30)
,`plazo` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_solicitudessinautorizar`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_solicitudessinautorizar` (
`username` varchar(50)
,`ID_Solicitud` int(11)
,`Detalle` int(11)
,`Estado` tinyint(1)
,`Autorizacion` tinyint(1)
,`usuario` int(11)
,`id_detalle` int(11)
,`Monto` double
,`edad` int(11)
,`forma_de_pago` varchar(30)
,`plazo` int(11)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_historial`
--
DROP TABLE IF EXISTS `vw_historial`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_historial`  AS  select `u`.`username` AS `username`,`s`.`ID_Solicitud` AS `ID_Solicitud`,`s`.`Detalle` AS `Detalle`,`s`.`Estado` AS `Estado`,`s`.`Autorizacion` AS `Autorizacion`,`s`.`usuario` AS `usuario`,`d`.`id_detalle` AS `id_detalle`,`d`.`Monto` AS `Monto`,`d`.`edad` AS `edad`,`d`.`forma_de_pago` AS `forma_de_pago`,`d`.`plazo` AS `plazo` from ((`usuario` `u` join `solicitudes` `s` on((`s`.`usuario` = `u`.`userID`))) join `detalle` `d` on((`d`.`id_detalle` = `s`.`Detalle`))) where (`s`.`Autorizacion` = 1) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_solicitudespendientes`
--
DROP TABLE IF EXISTS `vw_solicitudespendientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_solicitudespendientes`  AS  select `u`.`username` AS `username`,`s`.`ID_Solicitud` AS `ID_Solicitud`,`s`.`Detalle` AS `Detalle`,`s`.`Estado` AS `Estado`,`s`.`Autorizacion` AS `Autorizacion`,`s`.`usuario` AS `usuario`,`d`.`id_detalle` AS `id_detalle`,`d`.`Monto` AS `Monto`,`d`.`edad` AS `edad`,`d`.`forma_de_pago` AS `forma_de_pago`,`d`.`plazo` AS `plazo` from ((`usuario` `u` join `solicitudes` `s` on((`s`.`usuario` = `u`.`userID`))) join `detalle` `d` on((`d`.`id_detalle` = `s`.`Detalle`))) where ((`s`.`Estado` = 0) and (`s`.`Autorizacion` = 1)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_solicitudessinautorizar`
--
DROP TABLE IF EXISTS `vw_solicitudessinautorizar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_solicitudessinautorizar`  AS  select `u`.`username` AS `username`,`s`.`ID_Solicitud` AS `ID_Solicitud`,`s`.`Detalle` AS `Detalle`,`s`.`Estado` AS `Estado`,`s`.`Autorizacion` AS `Autorizacion`,`s`.`usuario` AS `usuario`,`d`.`id_detalle` AS `id_detalle`,`d`.`Monto` AS `Monto`,`d`.`edad` AS `edad`,`d`.`forma_de_pago` AS `forma_de_pago`,`d`.`plazo` AS `plazo` from ((`usuario` `u` join `solicitudes` `s` on((`s`.`usuario` = `u`.`userID`))) join `detalle` `d` on((`d`.`id_detalle` = `s`.`Detalle`))) where ((`s`.`Estado` = 0) and (`s`.`Autorizacion` = 0)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`id_detalle`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`ID_Solicitud`),
  ADD KEY `usuario` (`usuario`),
  ADD KEY `Detalle` (`Detalle`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `ID_Solicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `solicitudes_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `usuario` (`userID`),
  ADD CONSTRAINT `solicitudes_ibfk_2` FOREIGN KEY (`Detalle`) REFERENCES `detalle` (`id_detalle`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
